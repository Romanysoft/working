//
//  displayhelper.m
//  displayhelper
//
//  Created by Ian on 9/8/14.
//  Copyright (c) 2014 Ian. All rights reserved.
//

#import "displayhelper.h"

/////////////////////////////////////////////////////////////////////////////////////
#pragma mark - 引入处理接口处理功能
//#include "cjsonLib/include/cjson.h"
#include "interface_romanysoft.h"
#include "stdarg.h"

//{封装常用的汇报信息}

//发送启动消息
void g_romanysoft_send_start_info(){
    //构造json数据
    NSMutableDictionary* info = [NSMutableDictionary dictionary];
    [info setObject:[NSString stringWithUTF8String:START_EXECCOMMANDOPERATION_ROMANYSOFT] forKey:[NSString stringWithUTF8String:INFO_INFOTYPE_ROMANYSOFT]];
    [info setObject:[NSString stringWithUTF8String:"start..."] forKey:[NSString stringWithUTF8String:INFO_INFOTEXT_ROMANYSOFT]];
    NSString* json = [DisplayHelper getDictionaryToString:info];
    cb_reportExecState([json UTF8String]);
}

//发送命令行处理的消息
void g_romanysoft_send_end_info(){
    //构造json数据
    NSMutableDictionary* info = [NSMutableDictionary dictionary];
    [info setObject:[NSString stringWithUTF8String:END_EXECCOMMANDOPERATION_ROMANYSOFT] forKey:[NSString stringWithUTF8String:INFO_INFOTYPE_ROMANYSOFT]];
    [info setObject:[NSString stringWithUTF8String:"end..."] forKey:[NSString stringWithUTF8String:INFO_INFOTEXT_ROMANYSOFT]];
    NSString* json = [DisplayHelper getDictionaryToString:info];
    cb_reportExecState([json UTF8String]);
}

//发送错误信息
void g_romanysoft_send_error(const char* error){
    //构造json数据
    NSMutableDictionary* info = [NSMutableDictionary dictionary];
    [info setObject:[NSString stringWithUTF8String:ERROR_EXECCOMMANDOPERATION_ROMANYSOFT] forKey:[NSString stringWithUTF8String:INFO_INFOTYPE_ROMANYSOFT]];
    [info setObject:[NSString stringWithUTF8String:error] forKey:[NSString stringWithUTF8String:INFO_INFOTEXT_ROMANYSOFT]];
    NSString* json = [DisplayHelper getDictionaryToString:info];
    romanysoft_g_have_error = true;
    cb_reportExecState([json UTF8String]);
    
}

//发送进度信息
void g_romanysoft_send_progress(const double percent){
    //构造json数据
    NSMutableDictionary* info = [NSMutableDictionary dictionary];
    [info setObject:[NSString stringWithUTF8String:PROGRESS_EXECCOMMANDOPERATION_ROMANYSOFT] forKey:[NSString stringWithUTF8String:INFO_INFOTYPE_ROMANYSOFT]];
    [info setObject:[NSNumber numberWithDouble:percent] forKey:[NSString stringWithUTF8String:INFO_INFOPER_ROMANYSOFT]];
    NSString* json = [DisplayHelper getDictionaryToString:info];
    cb_reportExecState([json UTF8String]);
}

//发送进度日志信息
void g_romanysoft_send_progressWithInfo(const char* log) {
    //构造json数据
    NSMutableDictionary* info = [NSMutableDictionary dictionary];
    [info setObject:[NSString stringWithUTF8String:PROGRESS_EXECCOMMANDOPERATION_ROMANYSOFT] forKey:[NSString stringWithUTF8String:INFO_INFOTYPE_ROMANYSOFT]];
    [info setObject:[NSString stringWithUTF8String:log] forKey:[NSString stringWithUTF8String:INFO_INFOTEXT_ROMANYSOFT]];
    NSString* json = [DisplayHelper getDictionaryToString:info];
    cb_reportExecState([json UTF8String]);
}


int main(int argc, char *argv[]) {
    DisplayHelper* helper = [DisplayHelper shareDisplayHelper];
    
    optind = 1;
    int opt;
    while ((opt = getopt(argc, argv, "gps:mu")) != -1) {
        NSLog(@"当前的选项为 %d", opt);
        
        switch (opt) {
            case 'g':
                NSLog(@"call getAllSupportResolution");
                [helper getAllSupportResolution];
                break;
            case 's':
            {
                NSString* resStr = [NSString stringWithUTF8String:optarg];
                [helper setResolution:resStr];
            }
                break;
            case 'p':
                [helper getDefault];
                break;
            case 'm':
                [helper makeDefault];
                break;
            case 'u':
                [helper useDefault];
                break;
                
            default:
                break;
        }
    }
    
    
    return 0;
}

///
int execCLI( int argc, char *argv[], char* life_arg  )
{
    return execCLI2(argc, argv, life_arg, 0);
}


///
int execCLI2( int argc, char *argv[], char* life_arg, char* jsondata)
{
    if (strcmp(life_arg, CHECK_LIFE_ROMANYSOFT) != 0) {
        return RETURNCODE_DEFAULT_ROMANYSOFT;
    }
    
    //默认初始化是没有错误的，后面进行处理，查看是否有错误出现
    romanysoft_g_have_error = false;
    g_romanysoft_send_start_info();
    
    int returnCode = main(argc, argv);
    g_romanysoft_send_end_info();
    
    if (romanysoft_g_have_error) {
        returnCode = -1;
    }
    
    return returnCode;
}