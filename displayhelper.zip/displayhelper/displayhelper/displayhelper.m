//
//  displayhelper.m
//  displayhelper
//
//  Created by Ian on 9/8/14.
//  Copyright (c) 2014 Ian. All rights reserved.
//

#import "displayhelper.h"

@implementation DisplayHelper

@synthesize dataInfoDic;
@synthesize dataInfoFilePath;
@synthesize currentDisplay;

static NSString* kPluginPresetAll_const = @"plugin.preset.all";
static NSString* DEFAULT_KEY = @"default_key";
static DisplayHelper* static_helper = nil;

+ (DisplayHelper *)shareDisplayHelper {
    if (nil == static_helper) {
        static_helper = [[DisplayHelper alloc] init];
    }
    
    return static_helper;
}

#pragma mark - 公共函数
+(NSString *)getArrayToString:(NSArray*) _array{
    NSError* error = nil;
    id jsonData = nil;
    
    jsonData = [NSJSONSerialization dataWithJSONObject:_array
                                               options:NSJSONWritingPrettyPrinted
                                                 error:&error];
    if (error != nil) {
        NSLog(@"NSArray JSONString error: %@", [error localizedDescription]);
        return nil;
    } else {
        return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    }
}

+(NSString*)getDictionaryToString:(NSDictionary*) _dic{
    NSError* error = nil;
    id jsonData = nil;
    jsonData = [NSJSONSerialization dataWithJSONObject:_dic
                                               options:NSJSONWritingPrettyPrinted
                                                 error:&error];
    
    if (error != nil) {
        NSLog(@"NSDictionary JSONString error: %@", [error localizedDescription]);
        return nil;
    } else {
        return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    }
}

+(id)getJSONObject:(NSString*) jsonString
{
    NSError* error = nil;
    id object = nil;
    
    object = [NSJSONSerialization JSONObjectWithData:[jsonString dataUsingEncoding:NSUTF8StringEncoding]
                                             options:kNilOptions
                                               error:&error];
    
    NSLog(@"jsonObj = %@", object);
    if (error != nil) {
        NSLog(@"NSString JSONObject error: %@", [error localizedDescription]);
    }
    
    return object;
}

- (id) init{
    if ((self = [super init])){
        // 本地存储数据内容
        self.dataInfoFilePath = [NSString stringWithFormat:@"%@/app_data_info.plist", NSHomeDirectory()];
        
        BOOL isDir;
        // 如果不存在，说明是第一次使用
        if ([[NSFileManager defaultManager] fileExistsAtPath:self.dataInfoFilePath isDirectory:&isDir] && !isDir) {
            self.dataInfoDic = [[NSMutableDictionary alloc] initWithContentsOfFile:self.dataInfoFilePath];
        }else{
            self.dataInfoDic = [NSMutableDictionary dictionary];
        }
        
        // 注册消息处理
        [[NSNotificationCenter defaultCenter] addObserver: self
                                                 selector: @selector(onWindowDidChangeScreen:)
                                                     name: NSWindowDidChangeScreenNotification
                                                   object: nil];
        
        [self handleDisplayChanged];
        
    }
    
    return self;
}

//http://stackoverflow.com/questions/25378135/adding-nsnotification-cause-app-crash
/**
 The issue you have is that when you call:
 
 SubClass1 *class1 = [[SubClass1 alloc] init];
 you register class1 to be observer but after that line:
 
 [class1 method1];
 the object is deallocated and when you go to background the NSNotificationCenter try call a method handleAppBackground on that class (which is deallocated) what cause the crush. To solve it just remove this class to be an observer, add this method to SubClass1.m:
 
 -(void)dealloc {
 [[NSNotificationCenter defaultCenter] removeObserver:self];
 }
**/
// 必须加上dealloc,不然，与主线程的消息处理会发生崩溃
-(void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)onWindowDidChangeScreen:(NSNotification *)notification {
    [self handleDisplayChanged];
}

- (void)handleDisplayChanged {
    NSWindow* _window = [[NSApplication sharedApplication] mainWindow];
    
    if (_window) {
        currentDisplay = [ANDisplay displayWithScreen:[_window screen]];
        
        // filter out the bad settings
        NSArray * allSettings = [currentDisplay availableSettings];
        int maxBits = 0;
        
        for (ANDisplaySetting * setting in allSettings) {
            maxBits = MAX([setting bitsPerPixel], maxBits);
        }
        
        NSMutableArray * mUseSettings = [NSMutableArray array];
        for (ANDisplaySetting * setting in allSettings) {
            if ([setting scale] != 1) continue;
            if ([setting bitsPerPixel] < maxBits) continue;
            BOOL sizeExists = NO;
            for (ANDisplaySetting * prevSetting in mUseSettings) {
                if (CGSizeEqualToSize(prevSetting.size, setting.size)) {
                    sizeExists = YES;
                    break;
                }
            }
            if (!sizeExists) [mUseSettings addObject:setting];
        }
        
        availableSettings = [NSArray arrayWithArray:mUseSettings];
        
        //默认发送如下信息
        [self getCurResolution];
        [self getDefault];
    }
    
}


- (ANDisplaySetting *)getANDisplaySettingWithWidth:(int) width withHeight:(int) height
{
    for (ANDisplaySetting* s in availableSettings) {
        if ((s.size.width == width) && (s.size.height == height)) {
            return s;
        }
    }
    
    return nil;
}




#pragma mark - 接口处理
// 获得当前分辨率
- (ANDisplay * ) getCurResolution{
    ANDisplaySetting* setting = currentDisplay.currentSetting;
    NSString* preset = [NSString stringWithFormat:@"%d x %d", (int)setting.size.width, (int)setting.size.height];
    
    
    NSMutableDictionary* info = [NSMutableDictionary dictionary];
    [info setObject:preset forKey:@"getCurResolution"];
    
    NSString* json = [DisplayHelper getDictionaryToString:info];
    g_romanysoft_send_progressWithInfo([json UTF8String]);

    
    return currentDisplay;
}


// 获得所有支持的分辨率
- (void) getAllSupportResolution{
    
    NSMutableArray* _array = [NSMutableArray array];
    for (ANDisplaySetting* setting in availableSettings) {
        NSString* preset = [NSString stringWithFormat:@"%d x %d", (int)setting.size.width, (int)setting.size.height];
        [_array addObject:preset];
    }
    
    NSMutableDictionary* info = [NSMutableDictionary dictionary];
    [info setObject:_array forKey:@"getAllSupportResolution"];
    
    NSString* json = [DisplayHelper getDictionaryToString:info];
    g_romanysoft_send_progressWithInfo([json UTF8String]);
    
    //默认发送如下信息
    [self getCurResolution];
    [self getDefault];
    
}


// 设置分辨率
- (void) setResolution:(NSString*) resStr
{
    NSArray* strArray = [resStr componentsSeparatedByString:@" x "];
    int res_width = [strArray[0] intValue];
    int res_height = [strArray[1] intValue];
    
    NSMutableDictionary* info = [NSMutableDictionary dictionary];
    
    ANDisplaySetting* setting = [self getANDisplaySettingWithWidth:res_width withHeight:res_height];
    if (setting) {
        [currentDisplay setCurrentSetting:setting];
        [info setObject:[NSNumber numberWithBool:YES] forKey:@"setResolution"];
    }else{
         [info setObject:[NSNumber numberWithBool:NO] forKey:@"setResolution"];
    }
    
    NSString *json = [DisplayHelper getDictionaryToString:info];
    g_romanysoft_send_progressWithInfo([json UTF8String]);
    
    [self handleDisplayChanged];
}

// 设置默认的分辨率
- (void) makeDefault
{
    ANDisplaySetting * setting = [currentDisplay currentSetting];
    NSString* preset = [NSString stringWithFormat:@"%d x %d", (int)setting.size.width, (int)setting.size.height];
    
    [self.dataInfoDic setObject:preset forKey:DEFAULT_KEY];
    [self.dataInfoDic writeToFile:self.dataInfoFilePath atomically:YES];

    NSMutableDictionary* info = [NSMutableDictionary dictionary];
    [info setObject:preset forKey:@"makeDefault"];
    NSString *json = [DisplayHelper getDictionaryToString:info];
    g_romanysoft_send_progressWithInfo([json UTF8String]);
}

// 获取默认的分辨率
- (ANDisplaySetting*) getDefault
{
    ANDisplaySetting * default_setting = nil;
    for (ANDisplaySetting * setting in availableSettings) {
        NSString* preset = [NSString stringWithFormat:@"%d x %d", (int)setting.size.width, (int)setting.size.height];
        NSString* default_preset = [self.dataInfoDic objectForKey:DEFAULT_KEY];
        
        if ([preset isEqualToString:default_preset]) {
            default_setting = setting;
            NSMutableDictionary* info = [NSMutableDictionary dictionary];
            [info setObject:preset forKey:@"getDefault"];
            NSString *json = [DisplayHelper getDictionaryToString:info];
            g_romanysoft_send_progressWithInfo([json UTF8String]);

        }
    }
    
    if (!default_setting) {
        NSMutableDictionary* info = [NSMutableDictionary dictionary];
        [info setObject:@"NoSet" forKey:@"getDefault"];
        NSString *json = [DisplayHelper getDictionaryToString:info];
        g_romanysoft_send_progressWithInfo([json UTF8String]);
    }
    
    return default_setting;
}

// 使用默认的分辨率
- (void)useDefault
{
    ANDisplaySetting * default_setting = [self getDefault];
    if (default_setting) {
        NSString* preset = [NSString stringWithFormat:@"%d x %d", (int)default_setting.size.width, (int)default_setting.size.height];
        [self setResolution:preset];
        
        NSMutableDictionary* info = [NSMutableDictionary dictionary];
        [info setObject:preset forKey:@"useDefault"];
        NSString *json = [DisplayHelper getDictionaryToString:info];
        g_romanysoft_send_progressWithInfo([json UTF8String]);
        
    }
}


@end

