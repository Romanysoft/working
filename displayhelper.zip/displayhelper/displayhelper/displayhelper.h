//
//  displayhelper.h
//  displayhelper
//
//  Created by Ian on 9/8/14.
//  Copyright (c) 2014 Ian. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ANDisplay.h"

@interface DisplayHelper : NSObject {
    NSArray * availableSettings;
    NSMutableDictionary* product2PresetDic; // 映射表
    NSMutableDictionary* Prices2product;    // 价格映射表
}

@property (nonatomic, retain) NSMutableDictionary* dataInfoDic;
@property (nonatomic, retain) NSString* dataInfoFilePath;
@property (nonatomic, retain) ANDisplay * currentDisplay;


+ (DisplayHelper *) shareDisplayHelper;

#pragma mark - 公用函数
+(NSString *)getArrayToString:(NSArray*) _array;
+(NSString*)getDictionaryToString:(NSDictionary*) _dic;
+(id)getJSONObject:(NSString*) jsonString;

#pragma mark - 提供给外部的接口
- (void) getAllSupportResolution;
- (void) setResolution:(NSString*) resStr;
- (void) makeDefault;
- (void) useDefault;
- (ANDisplaySetting*) getDefault;


@end
