/**
 * Created by Ian on 2015/3/5.
 */

(function () {
    window['UI'] = window['UI'] || {};
    window.UI.c$ = window.UI.c$ || {};
})();

(function () {
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    var c$ = {};
    var b$ = BS.b$;
    c$ = $.extend(window.UI.c$, {});


    // 初始化标题及版本
    c$.initTitleAndVersion = function(){
        document.title = b$.App.getAppName();
    };


    // 设置UI部分与逻辑交互
    c$.setupUI = function(){
        "use strict";
        $(function () {
            var testEditor = editormd("test-editormd", {
                width: "98%",
                height: "760",
                path: 'common/editor.md/lib/',
                toolbarIcons: function () {
                    return ["undo", "redo", "|",
                        "bold","del", "italic", "quote", "|",
                        "h1", "h2", "h4", "h4", "h5", "h6", "|",
                        "list-ul", "list-ol", "hr", "|",
                        "link", "anchor", "image", "code", "|",
                        "preview", "watch", "|",
                        "fullscreen", "clear"]
                }
            });
        });

    };


    // 启动
    c$.launch = function(){
        "use strict";
        c$.initTitleAndVersion();
        c$.setupUI();
    }
}());