var csv = require('csv');

module.exports = function(codecs){
    codecs['csv'] = {
        defaults: {
            enc:{
                header: true
            },
            dec:{
                columns: true
            }
        },
        encoder:function(data, options, done){
            csv.stringify(data, options, function(err, r) {
                done(null, r);
            });
        },
        decoder:function(data, options, done){
            csv.parse(data, options, function(err, r) {
                done(err, r);
            });
        },
    }
}