module.exports = function(app){
    var Convert = require('./convert');
    app.post('/convert', function(req, res){
        Convert(req.body, function(err, output){
            if (err) {
                console.log(err);
                var errMsg;
                if (err instanceof Convert.Error) {
                    errMsg = res.tr('app', err.message);
                } else {
                    errMsg = res.tr('app.error');
                }
                return res.ajaxError(errMsg);
            }
            res.ajaxSuccess(output);
        })
    });
}
