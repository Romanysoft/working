
module.exports = function(codecs){
    codecs['json'] = {
        defaults: {
            enc:{
                indent: 4
            }
        },
        encoder:function(data, options, done){
            try{
                var r = JSON.stringify(data, null, options.indent);
            } catch (err) {
                return done(err);
            }
            done(null, r);
        },
        decoder:function(data, options, done){
            try{
                var r = JSON.parse(data);
            } catch (err) {
                return done(err);
            }
            done(null, r);
        },
    }
}