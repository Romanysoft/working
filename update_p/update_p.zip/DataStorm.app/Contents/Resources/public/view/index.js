def([
    'common',
    '{!T}tmpl/index.html',
    'native',
    'store',
    'view/setting',
    
    'view/header'
    ], function(com, tindex, ntv, store, svm){
    var ivm;
    var view = tiny.view({
        'classes':'view-index'
        ,render:function(r, done){
            ivm = window.ivm = new Vue({
                el:$(tindex({}))[0],
                data:{
                    taskList : [],
                    activeCount : 0
                },
                methods:{
                    remove:function(idx){
                        this.taskList.splice(idx, 1);
                    },
                    revealInFinder:function(path){
                        ntv.revealInFinder(path, function(filePath){
                            console.log('location:%s', filePath)
                        });
                    }
                },
                compiled: function(){
                    var $el = $(this.$el).appendTo(view.el());
                    var len = this.taskList.length;
                    this.$watch('activeCount', function(newVal){
                        if (newVal) {
                            NProgress.isStarted() || NProgress.start();
                        } else if (newVal == 0) {
                            NProgress.done();
                        } else {
                            NProgress.set((len - newVal) / len); 
                        }
                    })
                }
            });
            done();
        }
    })
    
    function getUrlExt(val, _url){
        return (_url = String(val || '')
                .replace(/(\?.*)|(#.*)/,'')
                .match(/\.([a-zA-z0-9]+)$/i)
               ) ? _url[1] :''
    }
    
    $(document)
        .on('click', '[tag-action="add"]', function(){
            ntv.importFile(ImportHandle.callback, {
                types:Object.keys(supportExts)
            }, function(cb){
                [
                    'csv2json.csv',
                    'json2csv.json',
                    'json2csvWithHeader.json',
                    'json2yml.json',
                    'repository.xml',
                    'simple.xml',
                    'sublime-p.plist',
                    'sublime.json',
                    'theme-p.plist',
                    'theme.xml',
                    'yml2json.yml'
                    ].forEach(function(it){
                    cb(null, {
                        filePath:'E:/www/git/cppprojects/~project/cv/converter/test/fixtures/'+it,
                        fileName:it,
                        extension:getUrlExt(it)
                    });
                })
            })
        })
        .on('click', '[tag-action="clear"]', function(){
            ivm.taskList=[];
        })
        .on('click', '[tag-action-convert]', function(){
            var encoder = $(this).attr('tag-action-convert');
            var options = svm.options
            if (!options.dist){
               svm.show();
               return; 
            }
            if (ivm.taskList.length) {
                jet.each(ivm.taskList, function(_, it){
                    ivm.activeCount++;
                    $.ajax({
                        url: ntv.serverUrl('convert') +'?_lang='+ (store.getString('lang') || 'en'),
                        dataType:'JSON',
                        type:"POST",
                        data:{
                            encoder:encoder,
                            decoder:it.decoder,
                            src:it.filePath,
                            distDir: options.dist,
                            override:options.override_if_exists
                        }
                    }).done(function(recv){
                        if (recv.error) {
                            it.status = 'error';
                        } else {
                            it.status = 'complete';
                        }
                        var data = recv.data;
                        it.distFile = data.distFile || '';
                        it.errMsg = recv.msg;
                        ivm.activeCount--;
                    }).fail(function(){
                        it.status = 'error';
                        it.distFile = '';
                        it.errMsg = jet.tr('error.connect_error');
                        ivm.activeCount--;
                        if (ivm.activeCount === 0) {
                            alertify.log(jet.tr('error.connect_restart'));
                        }
                    })
                })
            }
        })
    
    var supportExts = {
        json  :'c1',
        xml   :'c2',
        plist :'c3',
        csv   :'c4',
        yml   :'c5',
    }
    
    Vue.filter('ext_class', function(ext){
        return supportExts[ext];
    })
    
    var ImportHandle = {
        callback:function(err, it){
            if (err) {
                alertify.log(err.message);
            } else {
                it.decoder = it.extension = it.extension.toLowerCase();
                it.status = 'waitting';
                it.distFile = '';
                if (it.extension in supportExts) {
                    ivm.taskList.push(it);
                }
            }
        }
    }
    
    ntv.init({ 
        dragdrop:ImportHandle
    });
    return view;
})
